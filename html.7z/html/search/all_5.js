var searchData=
[
  ['player_0',['Player',['../class_futball_simulator_1_1_player.html',1,'FutballSimulator']]],
  ['players_1',['Players',['../class_futball_simulator_1_1_team.html#a952986fd8d976ac2542bc599fff6bbbc',1,'FutballSimulator::Team']]],
  ['position_2',['Position',['../class_futball_simulator_1_1_player.html#a5938de861f79cdb78e38cb8fb3d5f716',1,'FutballSimulator::Player']]],
  ['program_3',['Program',['../class_program.html',1,'']]]
];
