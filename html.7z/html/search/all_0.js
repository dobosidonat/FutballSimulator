var searchData=
[
  ['addplayer_0',['AddPlayer',['../class_futball_simulator_1_1_team.html#aaac6ed8017989d376b37d26472c983b6',1,'FutballSimulator::Team']]],
  ['age_1',['Age',['../class_futball_simulator_1_1_player.html#a5a634fff0105ce3578827a3bfb4b0db6',1,'FutballSimulator::Player']]]
];
