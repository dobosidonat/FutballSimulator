var searchData=
[
  ['marketvalue_0',['MarketValue',['../class_futball_simulator_1_1_player.html#a7c1e927b702270c1fcba581537eab41e',1,'FutballSimulator::Player']]]
];
