var searchData=
[
  ['age_0',['Age',['../class_futball_simulator_1_1_player.html#a5a634fff0105ce3578827a3bfb4b0db6',1,'FutballSimulator::Player']]]
];
