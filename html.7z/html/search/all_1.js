var searchData=
[
  ['budget_0',['Budget',['../class_futball_simulator_1_1_team.html#af5d72f8c01459c47470139b70f8d3bc4',1,'FutballSimulator::Team']]]
];
