var searchData=
[
  ['players_0',['Players',['../class_futball_simulator_1_1_team.html#a952986fd8d976ac2542bc599fff6bbbc',1,'FutballSimulator::Team']]],
  ['position_1',['Position',['../class_futball_simulator_1_1_player.html#a5938de861f79cdb78e38cb8fb3d5f716',1,'FutballSimulator::Player']]]
];
