var searchData=
[
  ['team_0',['Team',['../class_futball_simulator_1_1_team.html',1,'FutballSimulator']]]
];
