var searchData=
[
  ['rating_0',['Rating',['../class_futball_simulator_1_1_player.html#a35e11c2b90025c674a9b7d5850ca0950',1,'FutballSimulator::Player']]]
];
