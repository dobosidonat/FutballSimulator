var searchData=
[
  ['player_0',['Player',['../class_futball_simulator_1_1_player.html',1,'FutballSimulator']]],
  ['program_1',['Program',['../class_program.html',1,'']]]
];
