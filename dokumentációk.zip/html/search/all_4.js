var searchData=
[
  ['name_0',['Name',['../class_futball_simulator_1_1_player.html#a11cbaa9b236481b268ec0692f39a39d7',1,'FutballSimulator.Player.Name'],['../class_futball_simulator_1_1_team.html#ad3794f2ab20ca6a74dc5d403269d83a0',1,'FutballSimulator.Team.Name']]]
];
